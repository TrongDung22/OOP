﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class Program
    {
        static void Main(string[] args)
        {
            bai11.Run();
        }
    }
}
