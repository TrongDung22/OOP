﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai1
    {
        // Đổi tên Main thành Run để tránh nhiều điểm khởi đầu
        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch
            {
            }

            Console.Write("Nhập chiều dài: ");
            string input = Console.ReadLine();
            if (!TryReadDouble(input, out double length))
            {
                Console.WriteLine("Giá trị không hợp lệ cho chiều dài.");
                Pause();
                return;
            }

            Console.Write("Nhập chiều rộng: ");
            input = Console.ReadLine();
            if (!TryReadDouble(input, out double width))
            {
                Console.WriteLine("Giá trị không hợp lệ cho chiều rộng.");
                Pause();
                return;
            }

            double perimeter = 2 * (length + width);
            double area = length * width;

            Console.WriteLine($"Chu vi: {perimeter}");
            Console.WriteLine($"Diện tích: {area}");

            Pause();
        }

        static bool TryReadDouble(string s, out double value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            if (double.TryParse(s, out value)) return true;
            s = s.Replace(',', '.');
            return double.TryParse(s, System.Globalization.NumberStyles.Any, System.Globalization.CultureInfo.InvariantCulture, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để thoát...");
            Console.ReadKey();
        }
    }
}
