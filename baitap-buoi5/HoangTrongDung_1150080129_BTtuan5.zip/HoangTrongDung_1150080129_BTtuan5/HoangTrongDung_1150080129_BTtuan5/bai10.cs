﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai10
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(false);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            string[] tryPaths = new[]
            {
                "input_array.txt",
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "input_array.txt"),
                Path.Combine(Directory.GetCurrentDirectory(), "input_array.txt")
            };

            string path = tryPaths.FirstOrDefault(File.Exists);

            if (path == null)
            {
                Console.WriteLine("Không tìm thấy file 'input_array.txt' trong thư mục hiện tại.");
                Console.WriteLine("Hãy chắc chắn file tồn tại và được đặt trong thư mục chạy chương trình.");
                Pause();
                return;
            }

            string text;
            try
            {
                text = File.ReadAllText(path);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Không thể đọc file: {ex.Message}");
                Pause();
                return;
            }

            var tokens = text.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
            int[] arr;
            try
            {
                arr = tokens.Select(t => int.Parse(t.Trim())).ToArray();
            }
            catch (Exception)
            {
                Console.WriteLine("File chứa dữ liệu không hợp lệ. Hãy cung cấp các số nguyên cách nhau bằng khoảng trắng hoặc xuống dòng.");
                Pause();
                return;
            }

            Console.WriteLine("Mảng ban đầu: " + string.Join(" ", arr));

            // Selection sort ascending
            SelectionSort(arr);

            Console.WriteLine("Mảng sau khi sắp xếp tăng dần: " + string.Join(" ", arr));

            Pause();
        }

        static void SelectionSort(int[] a)
        {
            int n = a.Length;
            for (int i = 0; i < n - 1; i++)
            {
                int minIdx = i;
                for (int j = i + 1; j < n; j++)
                {
                    if (a[j] < a[minIdx]) minIdx = j;
                }
                if (minIdx != i)
                {
                    int tmp = a[i];
                    a[i] = a[minIdx];
                    a[minIdx] = tmp;
                }
            }
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
