﻿using System;
using System.IO;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai11
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(true);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            string[] tryPaths = new[]
            {
                "input_array.txt",
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "input_array.txt"),
                Path.Combine(Directory.GetCurrentDirectory(), "input_array.txt")
            };

            string path = tryPaths.FirstOrDefault(File.Exists);

            if (path == null)
            {
                Console.WriteLine("Không tìm thấy file 'input_array.txt' trong thư mục hiện tại.");
                Console.WriteLine("Hãy chắc chắn file tồn tại và được đặt trong thư mục chạy chương trình.");
                Pause();
                return;
            }

            string text;
            try
            {
                text = File.ReadAllText(path);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Không thể đọc file: {ex.Message}");
                Pause();
                return;
            }

            var tokens = text.Split((char[])null, StringSplitOptions.RemoveEmptyEntries);
            int[] arr;
            try
            {
                arr = tokens.Select(t => int.Parse(t.Trim())).ToArray();
            }
            catch (Exception)
            {
                Console.WriteLine("File chứa dữ liệu không hợp lệ. Hãy cung cấp các số nguyên cách nhau bằng khoảng trắng hoặc xuống dòng.");
                Pause();
                return;
            }

            Array.Sort(arr);
            Console.WriteLine("Mảng đã sắp xếp tăng dần: " + string.Join(" ", arr));

            int newValue;
            while (true)
            {
                Console.Write("Nhập số nguyên cần chèn vào mảng: ");
                string input = Console.ReadLine();
                if (TryReadInt(input, out newValue))
                    break;
                Console.WriteLine("Giá trị không hợp lệ, vui lòng nhập lại.");
            }

            int[] newArr = InsertIntoSortedArray(arr, newValue);

            Console.WriteLine($"Mảng sau khi chèn số {newValue}: " + string.Join(" ", newArr));
            Console.WriteLine($"Kích thước mảng: {arr.Length} → {newArr.Length}");

            Pause();
        }

        static int[] InsertIntoSortedArray(int[] sortedArray, int value)
        {
        
            int insertPosition = BinarySearchInsertPosition(sortedArray, value);
            
            
            int[] newArray = new int[sortedArray.Length + 1];
            
           
            for (int i = 0; i < insertPosition; i++)
            {
                newArray[i] = sortedArray[i];
            }
            
            
            newArray[insertPosition] = value;
            
            
            for (int i = insertPosition; i < sortedArray.Length; i++)
            {
                newArray[i + 1] = sortedArray[i];
            }
            
            return newArray;
        }

        static int BinarySearchInsertPosition(int[] sortedArray, int value)
        {
            int left = 0;
            int right = sortedArray.Length;
            
            while (left < right)
            {
                int mid = left + (right - left) / 2;
                
                if (sortedArray[mid] <= value)
                {
                    left = mid + 1;
                }
                else
                {
                    right = mid;
                }
            }
            
            return left;
        }

        static bool TryReadInt(string s, out int value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return int.TryParse(s, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}