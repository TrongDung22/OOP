﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai2
    {
        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            Console.Write("Nhập số nguyên a: ");
            string s = Console.ReadLine();
            if (!TryReadInt(s, out int a))
            {
                Console.WriteLine("Giá trị không hợp lệ cho a.");
                Pause();
                return;
            }

            Console.Write("Nhập số nguyên b: ");
            s = Console.ReadLine();
            if (!TryReadInt(s, out int b))
            {
                Console.WriteLine("Giá trị không hợp lệ cho b.");
                Pause();
                return;
            }

            if (a > b)
            {
                Console.WriteLine($"Số lớn hơn là a = {a}");
            }
            else if (b > a)
            {
                Console.WriteLine($"Số lớn hơn là b = {b}");
            }
            else
            {
                Console.WriteLine("Hai số bằng nhau.");
            }

            Pause();
        }

        static bool TryReadInt(string s, out int value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return int.TryParse(s, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
