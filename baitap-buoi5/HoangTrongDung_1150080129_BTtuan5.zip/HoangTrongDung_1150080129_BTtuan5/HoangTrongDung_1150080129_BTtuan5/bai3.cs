﻿using System;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai3
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(false);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            Console.Write("Nhập số nguyên a: ");
            string s = Console.ReadLine();
            if (!TryReadInt(s, out int a))
            {
                Console.WriteLine("Giá trị không hợp lệ cho a.");
                Pause();
                return;
            }

            Console.Write("Nhập số nguyên b: ");
            s = Console.ReadLine();
            if (!TryReadInt(s, out int b))
            {
                Console.WriteLine("Giá trị không hợp lệ cho b.");
                Pause();
                return;
            }

            Console.Write("Nhập số nguyên c: ");
            s = Console.ReadLine();
            if (!TryReadInt(s, out int c))
            {
                Console.WriteLine("Giá trị không hợp lệ cho c.");
                Pause();
                return;
            }

            int max = a;
            if (b > max) max = b;
            if (c > max) max = c;

            Console.WriteLine($"Số lớn nhất là: {max}");

            Pause();
        }

        static bool TryReadInt(string s, out int value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return int.TryParse(s, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
