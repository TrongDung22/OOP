﻿using System;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai4
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(true);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            Console.Write("Nhập tháng (1-12): ");
            string s = Console.ReadLine();
            if (!TryReadInt(s, out int month) || month < 1 || month > 12)
            {
                Console.WriteLine("Giá trị tháng không hợp lệ.");
                Pause();
                return;
            }

            Console.Write("Nhập năm: ");
            s = Console.ReadLine();
            if (!TryReadInt(s, out int year) || year <= 0)
            {
                Console.WriteLine("Giá trị năm không hợp lệ.");
                Pause();
                return;
            }

            int days;
            switch (month)
            {
                case 1: // Jan
                case 3: // Mar
                case 5: // May
                case 7: // Jul
                case 8: // Aug
                case 10: // Oct
                case 12: // Dec
                    days = 31;
                    break;
                case 4: // Apr
                case 6: // Jun
                case 9: // Sep
                case 11: // Nov
                    days = 30;
                    break;
                case 2: // Feb
                    days = IsLeapYear(year) ? 29 : 28;
                    break;
                default:
                    days = 0; 
                    break;
            }

            Console.WriteLine($"Tháng {month} năm {year} có {days} ngày.");
            Pause();
        }

        static bool TryReadInt(string s, out int value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return int.TryParse(s, out value);
        }

        static bool IsLeapYear(int year)
        {
            // Năm nhuận: chia hết cho 400 hoặc (chia hết cho 4 nhưng không chia hết cho 100)
            return (year % 400 == 0) || (year % 4 == 0 && year % 100 != 0);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
