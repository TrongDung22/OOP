﻿using System;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai5
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(true);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            Console.Write("Nhập một số nguyên n: ");
            string s = Console.ReadLine();
            if (!TryReadInt(s, out int n))
            {
                Console.WriteLine("Giá trị không hợp lệ.");
                Pause();
                return;
            }

            // a) chẵn hay lẻ
            if (n % 2 == 0)
                Console.WriteLine($"a) {n} là số chẵn.");
            else
                Console.WriteLine($"a) {n} là số lẻ.");

            // b) âm hay không âm
            if (n < 0)
                Console.WriteLine($"b) {n} là số âm.");
            else
                Console.WriteLine($"b) {n} là số không âm.");

            Pause();
        }

        static bool TryReadInt(string s, out int value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return int.TryParse(s, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
