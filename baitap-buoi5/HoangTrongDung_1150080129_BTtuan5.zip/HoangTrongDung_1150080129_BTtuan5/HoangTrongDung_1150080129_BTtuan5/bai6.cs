﻿using System;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai6
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(true);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            Console.Write("Nhập chiều dài (>0): ");
            string s = Console.ReadLine();
            if (!TryReadDouble(s, out double length) || length <= 0)
            {
                Console.WriteLine("Giá trị chiều dài không hợp lệ.");
                Pause();
                return;
            }

            Console.Write("Nhập chiều rộng (>0): ");
            s = Console.ReadLine();
            if (!TryReadDouble(s, out double width) || width <= 0)
            {
                Console.WriteLine("Giá trị chiều rộng không hợp lệ.");
                Pause();
                return;
            }

            double perimeter = 2 * (length + width);
            double area = length * width;

            Console.WriteLine($"Chu vi hình chữ nhật: {perimeter}");
            Console.WriteLine($"Diện tích hình chữ nhật: {area}");

            Pause();
        }

        static bool TryReadDouble(string s, out double value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return double.TryParse(s, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
