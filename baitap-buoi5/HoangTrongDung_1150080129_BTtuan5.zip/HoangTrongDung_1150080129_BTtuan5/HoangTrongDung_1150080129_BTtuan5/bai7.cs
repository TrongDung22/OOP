﻿using System;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai7
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(true);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            Console.Write("Nhập độ dài đoạn thẳng thứ nhất (>0): ");
            string s = Console.ReadLine();
            if (!TryReadDouble(s, out double a) || a <= 0)
            {
                Console.WriteLine("Giá trị không hợp lệ cho đoạn thẳng thứ nhất.");
                Pause();
                return;
            }

            Console.Write("Nhập độ dài đoạn thẳng thứ hai (>0): ");
            s = Console.ReadLine();
            if (!TryReadDouble(s, out double b) || b <= 0)
            {
                Console.WriteLine("Giá trị không hợp lệ cho đoạn thẳng thứ hai.");
                Pause();
                return;
            }

            Console.Write("Nhập độ dài đoạn thẳng thứ ba (>0): ");
            s = Console.ReadLine();
            if (!TryReadDouble(s, out double c) || c <= 0)
            {
                Console.WriteLine("Giá trị không hợp lệ cho đoạn thẳng thứ ba.");
                Pause();
                return;
            }

            // Kiểm tra điều kiện tam giác: tổng hai cạnh phải lớn hơn cạnh còn lại
            if (a + b > c && a + c > b && b + c > a)
            {
                double perimeter = a + b + c;
                double sHalf = perimeter / 2.0;
                double area = Math.Sqrt(Math.Max(0.0, sHalf * (sHalf - a) * (sHalf - b) * (sHalf - c)));

                Console.WriteLine($"Tam giác hợp lệ.");
                Console.WriteLine($"Chu vi: {perimeter}");
                Console.WriteLine($"Diện tích: {area}");
            }
            else
            {
                Console.WriteLine("Ba đoạn thẳng không lập thành tam giác.");
            }

            Pause();
        }

        static bool TryReadDouble(string s, out double value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return double.TryParse(s, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
