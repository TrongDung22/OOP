﻿using System;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai8
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(true);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            Console.WriteLine("Giải phương trình bậc 2: ax^2 + bx + c = 0");

            Console.Write("Nhập a: ");
            string s = Console.ReadLine();
            if (!TryReadDouble(s, out double a))
            {
                Console.WriteLine("Giá trị không hợp lệ cho a.");
                Pause();
                return;
            }

            Console.Write("Nhập b: ");
            s = Console.ReadLine();
            if (!TryReadDouble(s, out double b))
            {
                Console.WriteLine("Giá trị không hợp lệ cho b.");
                Pause();
                return;
            }

            Console.Write("Nhập c: ");
            s = Console.ReadLine();
            if (!TryReadDouble(s, out double c))
            {
                Console.WriteLine("Giá trị không hợp lệ cho c.");
                Pause();
                return;
            }

            const double EPS = 1e-12;

            if (Math.Abs(a) < EPS)
            {
                // Linear or degenerate
                if (Math.Abs(b) < EPS)
                {
                    if (Math.Abs(c) < EPS)
                        Console.WriteLine("Phương trình có vô số nghiệm.");
                    else
                        Console.WriteLine("Phương trình vô nghiệm.");
                }
                else
                {
                    double x = -c / b;
                    Console.WriteLine($"Phương trình bậc nhất có nghiệm: x = {x}");
                }

                Pause();
                return;
            }

            double delta = b * b - 4 * a * c;

            if (delta > EPS)
            {
                double sqrtD = Math.Sqrt(delta);
                double x1 = (-b + sqrtD) / (2 * a);
                double x2 = (-b - sqrtD) / (2 * a);
                Console.WriteLine($"Phương trình có 2 nghiệm thực phân biệt:");
                Console.WriteLine($"x1 = {x1}");
                Console.WriteLine($"x2 = {x2}");
            }
            else if (Math.Abs(delta) <= EPS)
            {
                double x = -b / (2 * a);
                Console.WriteLine($"Phương trình có nghiệm kép: x = {x}");
            }
            else
            {
                // complex roots
                double real = -b / (2 * a);
                double imag = Math.Sqrt(-delta) / (2 * a);
                Console.WriteLine($"Phương trình có 2 nghiệm phức:");
                Console.WriteLine($"x1 = {real} + {imag}i");
                Console.WriteLine($"x2 = {real} - {imag}i");
            }

            Pause();
        }

        static bool TryReadDouble(string s, out double value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return double.TryParse(s, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
