﻿using System;
using System.Text;
using System.Runtime.InteropServices;

namespace HoangTrongDung_1150080129_BTtuan5
{
    internal class bai9
    {
        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleOutputCP(uint wCodePageID);

        [DllImport("kernel32.dll")]
        private static extern bool SetConsoleCP(uint wCodePageID);

        public static void Run()
        {
            try
            {
                Console.OutputEncoding = Encoding.UTF8;
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            try
            {
                Console.OutputEncoding = new UTF8Encoding(true);
                Console.InputEncoding = Encoding.UTF8;
            }
            catch { }

            Console.Write("Nhập số lượng phần tử n (>=1): ");
            string s = Console.ReadLine();
            if (!TryReadInt(s, out int n) || n <= 0)
            {
                Console.WriteLine("Giá trị n không hợp lệ.");
                Pause();
                return;
            }

            double sum = 0.0;
            for (int i = 0; i < n; i++)
            {
                double val;
                while (true)
                {
                    Console.Write($"Nhập phần tử thứ {i + 1}: ");
                    s = Console.ReadLine();
                    if (TryReadDouble(s, out val)) break;
                    Console.WriteLine("Giá trị không hợp lệ, vui lòng nhập lại.");
                }

                sum += val;
            }

            Console.WriteLine($"Tổng các phần tử trong mảng là: {sum}");
            Pause();
        }

        static bool TryReadInt(string s, out int value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return int.TryParse(s, out value);
        }

        static bool TryReadDouble(string s, out double value)
        {
            value = 0;
            if (string.IsNullOrWhiteSpace(s)) return false;
            s = s.Trim();
            return double.TryParse(s, out value);
        }

        static void Pause()
        {
            Console.WriteLine("Nhấn phím bất kỳ để quay lại...");
            Console.ReadKey();
        }
    }
}
