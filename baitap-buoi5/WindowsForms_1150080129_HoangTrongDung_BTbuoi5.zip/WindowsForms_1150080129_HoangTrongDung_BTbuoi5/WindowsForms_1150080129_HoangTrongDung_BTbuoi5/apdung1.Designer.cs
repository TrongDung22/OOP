﻿namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    partial class apdung1
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.grpInput = new System.Windows.Forms.GroupBox();
            this.grpOptions = new System.Windows.Forms.GroupBox();
            this.txtNumberA = new System.Windows.Forms.TextBox();
            this.txtNumberB = new System.Windows.Forms.TextBox();
            this.lblNumberA = new System.Windows.Forms.Label();
            this.lblNumberB = new System.Windows.Forms.Label();
            this.grpResult = new System.Windows.Forms.GroupBox();
            this.rdoGCD = new System.Windows.Forms.RadioButton();
            this.rdoLCM = new System.Windows.Forms.RadioButton();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnCalculate = new System.Windows.Forms.Button();
            this.txtResult = new System.Windows.Forms.TextBox();
            this.grpInput.SuspendLayout();
            this.grpOptions.SuspendLayout();
            this.grpResult.SuspendLayout();
            this.SuspendLayout();
            this.grpInput.BackColor = System.Drawing.Color.LightGreen;
            this.grpInput.Controls.Add(this.lblNumberB);
            this.grpInput.Controls.Add(this.lblNumberA);
            this.grpInput.Controls.Add(this.txtNumberB);
            this.grpInput.Controls.Add(this.txtNumberA);
            this.grpInput.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpInput.Location = new System.Drawing.Point(12, 12);
            this.grpInput.Name = "grpInput";
            this.grpInput.Size = new System.Drawing.Size(402, 197);
            this.grpInput.TabIndex = 1;
            this.grpInput.TabStop = false;
            this.grpInput.Text = "Nhập dữ liệu";
            this.grpOptions.BackColor = System.Drawing.SystemColors.ControlLight;
            this.grpOptions.Controls.Add(this.rdoLCM);
            this.grpOptions.Controls.Add(this.rdoGCD);
            this.grpOptions.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpOptions.Location = new System.Drawing.Point(473, 12);
            this.grpOptions.Name = "grpOptions";
            this.grpOptions.Size = new System.Drawing.Size(315, 197);
            this.grpOptions.TabIndex = 2;
            this.grpOptions.TabStop = false;
            this.grpOptions.Text = "Tùy chọn:";
            this.grpOptions.Enter += new System.EventHandler(this.grpOptions_Enter);
            this.txtNumberA.Location = new System.Drawing.Point(228, 60);
            this.txtNumberA.Multiline = true;
            this.txtNumberA.Name = "txtNumberA";
            this.txtNumberA.Size = new System.Drawing.Size(151, 41);
            this.txtNumberA.TabIndex = 0;
            this.txtNumberB.Location = new System.Drawing.Point(228, 131);
            this.txtNumberB.Multiline = true;
            this.txtNumberB.Name = "txtNumberB";
            this.txtNumberB.Size = new System.Drawing.Size(151, 41);
            this.txtNumberB.TabIndex = 1;
            this.lblNumberA.AutoSize = true;
            this.lblNumberA.Location = new System.Drawing.Point(63, 60);
            this.lblNumberA.Name = "lblNumberA";
            this.lblNumberA.Size = new System.Drawing.Size(122, 26);
            this.lblNumberA.TabIndex = 2;
            this.lblNumberA.Text = "Nhập số a:";
            this.lblNumberB.AutoSize = true;
            this.lblNumberB.Location = new System.Drawing.Point(63, 131);
            this.lblNumberB.Name = "lblNumberB";
            this.lblNumberB.Size = new System.Drawing.Size(123, 26);
            this.lblNumberB.TabIndex = 3;
            this.lblNumberB.Text = "Nhập số b:";
            this.grpResult.Controls.Add(this.txtResult);
            this.grpResult.Controls.Add(this.btnExit);
            this.grpResult.Controls.Add(this.btnCalculate);
            this.grpResult.Font = new System.Drawing.Font("Arial", 11F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.grpResult.Location = new System.Drawing.Point(12, 281);
            this.grpResult.Name = "grpResult";
            this.grpResult.Size = new System.Drawing.Size(736, 157);
            this.grpResult.TabIndex = 3;
            this.grpResult.TabStop = false;
            this.grpResult.Text = "Kết quả";
            this.grpResult.Enter += new System.EventHandler(this.grpResult_Enter);
            this.rdoGCD.AutoSize = true;
            this.rdoGCD.Location = new System.Drawing.Point(74, 61);
            this.rdoGCD.Name = "rdoGCD";
            this.rdoGCD.Size = new System.Drawing.Size(113, 30);
            this.rdoGCD.TabIndex = 2;
            this.rdoGCD.TabStop = true;
            this.rdoGCD.Text = "ƯSCLN";
            this.rdoGCD.UseVisualStyleBackColor = true;
            this.rdoLCM.AutoSize = true;
            this.rdoLCM.Location = new System.Drawing.Point(74, 118);
            this.rdoLCM.Name = "rdoLCM";
            this.rdoLCM.Size = new System.Drawing.Size(116, 30);
            this.rdoLCM.TabIndex = 3;
            this.rdoLCM.TabStop = true;
            this.rdoLCM.Text = "BSCNN";
            this.rdoLCM.UseVisualStyleBackColor = true;
            this.rdoLCM.CheckedChanged += new System.EventHandler(this.rdoLCM_CheckedChanged);
            this.btnExit.Location = new System.Drawing.Point(535, 87);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(103, 37);
            this.btnExit.TabIndex = 0;
            this.btnExit.Text = "Thoát";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnCalculate.Location = new System.Drawing.Point(535, 41);
            this.btnCalculate.Name = "btnCalculate";
            this.btnCalculate.Size = new System.Drawing.Size(103, 37);
            this.btnCalculate.TabIndex = 1;
            this.btnCalculate.Text = "Tìm";
            this.btnCalculate.UseVisualStyleBackColor = true;
            this.txtResult.Location = new System.Drawing.Point(132, 64);
            this.txtResult.Multiline = true;
            this.txtResult.Name = "txtResult";
            this.txtResult.ReadOnly = true;
            this.txtResult.Size = new System.Drawing.Size(374, 41);
            this.txtResult.TabIndex = 2;
            this.txtResult.TextChanged += new System.EventHandler(this.txtResult_TextChanged);
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.grpResult);
            this.Controls.Add(this.grpOptions);
            this.Controls.Add(this.grpInput);
            this.Name = "apdung1";
            this.Text = "Tìm ƯSCLN và BSCNN";
            this.Load += new System.EventHandler(this.apdung1_Load);
            this.grpInput.ResumeLayout(false);
            this.grpInput.PerformLayout();
            this.grpOptions.ResumeLayout(false);
            this.grpOptions.PerformLayout();
            this.grpResult.ResumeLayout(false);
            this.grpResult.PerformLayout();
            this.ResumeLayout(false);
        }
        private System.Windows.Forms.GroupBox grpInput;
        private System.Windows.Forms.Label lblNumberB;
        private System.Windows.Forms.Label lblNumberA;
        private System.Windows.Forms.TextBox txtNumberB;
        private System.Windows.Forms.TextBox txtNumberA;
        private System.Windows.Forms.GroupBox grpOptions;
        private System.Windows.Forms.GroupBox grpResult;
        private System.Windows.Forms.RadioButton rdoLCM;
        private System.Windows.Forms.RadioButton rdoGCD;
        private System.Windows.Forms.TextBox txtResult;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnCalculate;
    }
}