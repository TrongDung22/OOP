﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    public partial class apdung1 : Form
    {
        public apdung1()
        {
            InitializeComponent();
        }

        private void apdung1_Load(object sender, EventArgs e)
        {
            rdoGCD.Checked = true;

            btnCalculate.Click += btnCalculate_Click;
            btnExit.Click += btnExit_Click;

            txtNumberA.KeyPress += txtNumber_KeyPress;
            txtNumberB.KeyPress += txtNumber_KeyPress;
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtNumberA.Text) || string.IsNullOrWhiteSpace(txtNumberB.Text))
                {
                    MessageBox.Show("Vui lòng nhập đầy đủ hai số!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (!int.TryParse(txtNumberA.Text.Trim(), out int numberA) || !int.TryParse(txtNumberB.Text.Trim(), out int numberB))
                {
                    MessageBox.Show("Vui lòng nhập số nguyên hợp lệ!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (numberA <= 0 || numberB <= 0)
                {
                    MessageBox.Show("Vui lòng nhập số nguyên dương!", "Lỗi nhập liệu", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (rdoGCD.Checked)
                {
                    int gcd = CalculateGCD(numberA, numberB);
                    txtResult.Text = $"ƯSCLN({numberA}, {numberB}) = {gcd}";
                }
                else if (rdoLCM.Checked)
                {
                    int lcm = CalculateLCM(numberA, numberB);
                    txtResult.Text = $"BSCNN({numberA}, {numberB}) = {lcm}";
                }
                else
                {
                    MessageBox.Show("Vui lòng chọn tùy chọn tính toán!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Có lỗi xảy ra: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát?", "Xác nhận thoát",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }

        private void txtNumber_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar))
            {
                e.Handled = true;
            }
        }

        private int CalculateGCD(int a, int b)
        {
            while (b != 0)
            {
                int temp = b;
                b = a % b;
                a = temp;
            }
            return a;
        }

        private int CalculateLCM(int a, int b)
        {
            return Math.Abs(a * b) / CalculateGCD(a, b);
        }

        private void rdoLCM_CheckedChanged(object sender, EventArgs e)
        {
            if (rdoLCM.Checked || rdoGCD.Checked)
            {
                txtResult.Clear();
            }
        }

        private void txtResult_TextChanged(object sender, EventArgs e)
        {
        }

        private void grpOptions_Enter(object sender, EventArgs e)
        {
        }

        private void grpResult_Enter(object sender, EventArgs e)
        {
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
        }

        private void groupBox3_Enter(object sender, EventArgs e)
        {
        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {
        }
    }
}
