﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    public partial class apdung2 : Form
    {
        private Dictionary<string, List<string>> groupPasswords;
        private string currentInput = "";
        
        public apdung2()
        {
            InitializeComponent();
            InitializePasswords();
            InitializeInterface();
        }

        private void InitializePasswords()
        {
            groupPasswords = new Dictionary<string, List<string>>()
            {
                { "Phát triển công nghệ", new List<string> { "1496", "2673" } },
                { "Nghiên cứu viên", new List<string> { "7462" } },
                { "Thiết kế mô hình", new List<string> { "8884", "3842", "3383" } }
            };
        }

        private void InitializeInterface()
        {
            txtPassword.Text = "";
            txtPassword.Font = new Font("Microsoft Sans Serif", 16F, FontStyle.Bold);
            
            lvAccessLog.View = View.Details;
            lvAccessLog.FullRowSelect = true;
            lvAccessLog.GridLines = true;
            
            this.Text = "Security Panel - Lab Access Control System";
        }

        private void NumberButton_Click(object sender, EventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null && currentInput.Length < 10)
            {
                currentInput += btn.Text;
                UpdatePasswordDisplay();
            }
        }

        private void UpdatePasswordDisplay()
        {
            txtPassword.Text = new string('*', currentInput.Length);
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            currentInput = "";
            txtPassword.Text = "";
        }

        private void btnEnter_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(currentInput))
            {
                MessageBox.Show("Vui lòng nhập mật khẩu!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string groupName = ValidatePassword(currentInput);
            DateTime accessTime = DateTime.Now;
            
            if (!string.IsNullOrEmpty(groupName))
            {
                LogAccess(accessTime, groupName, "Chấp nhận");
                ShowAccessResult(true, groupName);
            }
            else
            {
                LogAccess(accessTime, "", "Từ chối");
                ShowAccessResult(false, "");
            }
            
            currentInput = "";
            txtPassword.Text = "";
        }

        private string ValidatePassword(string password)
        {
            foreach (var group in groupPasswords)
            {
                if (group.Value.Contains(password))
                {
                    return group.Key;
                }
            }
            return "";
        }

        private void LogAccess(DateTime dateTime, string groupName, string result)
        {
            ListViewItem item = new ListViewItem(dateTime.ToString("dd/MM/yyyy HH:mm:ss"));
            item.SubItems.Add(groupName);
            item.SubItems.Add(result);
            
            if (result == "Chấp nhận")
            {
                item.BackColor = Color.LightGreen;
            }
            else
            {
                item.BackColor = Color.LightCoral;
            }
            
            lvAccessLog.Items.Insert(0, item);
            
            while (lvAccessLog.Items.Count > 50)
            {
                lvAccessLog.Items.RemoveAt(lvAccessLog.Items.Count - 1);
            }
        }

        private void ShowAccessResult(bool granted, string groupName)
        {
            if (granted)
            {
                MessageBox.Show($"TRUY CẬP ĐƯỢC CHẤP NHẬN!\n\nNhóm: {groupName}\nThời gian: {DateTime.Now:dd/MM/yyyy HH:mm:ss}\n\nChào mừng bạn đến phòng Lab!", 
                    "Truy cập thành công", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                FlashForm(Color.LightGreen);
            }
            else
            {
                MessageBox.Show($"TRUY CẬP BỊ TỪ CHỐI!\n\nMật khẩu không đúng.\nThời gian: {DateTime.Now:dd/MM/yyyy HH:mm:ss}\n\nVui lòng liên hệ quản trị viên nếu cần hỗ trợ.", 
                    "Truy cập thất bại", MessageBoxButtons.OK, MessageBoxIcon.Error);
                
                FlashForm(Color.LightCoral);
            }
        }

        private async void FlashForm(Color color)
        {
            Color originalColor = this.BackColor;
            this.BackColor = color;
            await Task.Delay(500);
            this.BackColor = originalColor;
        }

        private async void btnRing_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("CHUÔNG KHẨN CẤP!\n\nBạn có muốn gọi bảo vệ không?", 
                "Báo động", MessageBoxButtons.YesNo, MessageBoxIcon.Exclamation);
            
            if (result == DialogResult.Yes)
            {
                DateTime ringTime = DateTime.Now;
                LogAccess(ringTime, "CHUÔNG KHẨN CẤP", "Đã gọi bảo vệ");
                
                MessageBox.Show("Đã thông báo cho bộ phận bảo vệ!\nThời gian: " + ringTime.ToString("dd/MM/yyyy HH:mm:ss"), 
                    "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                
                for (int i = 0; i < 3; i++)
                {
                    FlashForm(Color.Red);
                    await Task.Delay(300);
                }
            }
        }

        private void grpPassword_Enter(object sender, EventArgs e)
        {
        }
    }
}
