﻿using System;
using System.Windows.Forms;
using System.Text;

namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    public partial class apdung3 : Form
    {
        public apdung3()
        {
            InitializeComponent();
      
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
        
            if (string.IsNullOrWhiteSpace(txtUsername.Text))
            {
                MessageBox.Show("Vui lòng nhập tên đăng nhập!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtUsername.Focus();
                return;
            }

     
            if (string.IsNullOrWhiteSpace(txtPassword.Text))
            {
                MessageBox.Show("Vui lòng nhập mật khẩu!", "Cảnh báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPassword.Focus();
                return;
            }

    
            MessageBox.Show($"Đăng nhập thành công!\nTên đăng nhập: {txtUsername.Text}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
  
            txtUsername.Clear();
            txtPassword.Clear();
            txtUsername.Focus();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
       
            this.Close();
        }

        private void apdung3_Load(object sender, EventArgs e)
        {
   
            txtUsername.Focus();
        }
    }
}