﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    public partial class apdung4 : Form
    {
        public apdung4()
        {
            InitializeComponent();
            LoadComboBoxData();
        }

        private void LoadComboBoxData()
        {
            for (int i = 1; i <= 31; i++)
            {
                cmbNgay.Items.Add(i.ToString());
            }
            for (int i = 1; i <= 12; i++)
            {
                cmbThang.Items.Add(i.ToString());
            }
            for (int i = 1930; i <= 2010; i++)
            {
                cmbNam.Items.Add(i.ToString());
            }
        }

        private void btnKiemTra_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtHoTen.Text) || 
                cmbNgay.SelectedItem == null || 
                cmbThang.SelectedItem == null || 
                string.IsNullOrWhiteSpace(cmbNam.Text))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }
            try
            {
                int ngay = int.Parse(cmbNgay.SelectedItem.ToString());
                int thang = int.Parse(cmbThang.SelectedItem.ToString());
                int nam = int.Parse(cmbNam.Text);
                DateTime ngaySinh = new DateTime(nam, thang, ngay);
                string message = $"Họ tên: {txtHoTen.Text}\nNgày sinh: {ngay:D2}/{thang:D2}/{nam}";
                MessageBox.Show(message, "Thông tin", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception)
            {
                MessageBox.Show("Ngày sinh không hợp lệ!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}