﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    public partial class bai1 : Form
    {
        public bai1()
        {
            InitializeComponent();
            btnCong.Click += BtnCong_Click;
            btnTru.Click += BtnTru_Click;
            btnNhan.Click += BtnNhan_Click;
            btnChia.Click += BtnChia_Click;
            btnXoa.Click += BtnXoa_Click;
            btnThoat.Click += BtnThoat_Click;
            textBox3.ReadOnly = true;
            this.StartPosition = FormStartPosition.CenterScreen;
        }
        private void Form1_Load(object sender, EventArgs e)
        {
        }
        private bool LayGiaTriNhapVao(out double a, out double b)
        {
            if (!double.TryParse(textBox1.Text.Trim(), out a))
            {
                MessageBox.Show("Vui lòng nhập số hợp lệ cho số a!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox1.Focus();
                b = 0;
                return false;
            }
            if (!double.TryParse(textBox2.Text.Trim(), out b))
            {
                MessageBox.Show("Vui lòng nhập số hợp lệ cho số b!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                textBox2.Focus();
                return false;
            }
            return true;
        }
        private void BtnCong_Click(object sender, EventArgs e)
        {
            if (LayGiaTriNhapVao(out double a, out double b))
            {
                double ketQua = a + b;
                textBox3.Text = ketQua.ToString();
            }
        }
        private void BtnTru_Click(object sender, EventArgs e)
        {
            if (LayGiaTriNhapVao(out double a, out double b))
            {
                double ketQua = a - b;
                textBox3.Text = ketQua.ToString();
            }
        }
        private void BtnNhan_Click(object sender, EventArgs e)
        {
            if (LayGiaTriNhapVao(out double a, out double b))
            {
                double ketQua = a * b;
                textBox3.Text = ketQua.ToString();
            }
        }
        private void BtnChia_Click(object sender, EventArgs e)
        {
            if (LayGiaTriNhapVao(out double a, out double b))
            {
                if (b == 0)
                {
                    MessageBox.Show("Không thể chia cho 0!", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    textBox2.Focus();
                }
                else
                {
                    double ketQua = a / b;
                    textBox3.Text = ketQua.ToString();
                }
            }
        }
        private void BtnXoa_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear();
            textBox1.Focus(); 
        }
        private void BtnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn thoát khỏi chương trình?", 
                "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {
        }
        private void label2_Click(object sender, EventArgs e)
        {
        }
        private void label3_Click(object sender, EventArgs e)
        {
        }
        private void label4_Click(object sender, EventArgs e)
        {
        }
    }
}
