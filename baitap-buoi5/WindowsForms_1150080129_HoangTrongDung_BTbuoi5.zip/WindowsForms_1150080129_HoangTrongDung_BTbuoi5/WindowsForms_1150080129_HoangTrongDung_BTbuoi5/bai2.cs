﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    public partial class bai2 : Form
    {
        private const decimal GIA_LAY_CAO_RANG = 50000;
        private const decimal GIA_TAY_TRANG_RANG = 100000;
        private const decimal GIA_HAN_RANG = 100000;
        private const decimal GIA_NHO_RANG = 10000;
        private const decimal GIA_BOC_RANG = 1000000;
        public bai2()
        {
            InitializeComponent();
            InitializeForm();
        }
        private void InitializeForm()
        {
            nudHanRang.Minimum = 0;
            nudHanRang.Maximum = 32;
            nudNhoRang.Minimum = 0;
            nudNhoRang.Maximum = 32;
            nudBocRang.Minimum = 0;
            nudBocRang.Maximum = 32;
            nudHanRang.Value = 0;
            nudNhoRang.Value = 0;
            nudBocRang.Value = 0;
        }
        private void chkHanRang_CheckedChanged(object sender, EventArgs e)
        {
            nudHanRang.Enabled = chkHanRang.Checked;
            if (!chkHanRang.Checked)
            {
                nudHanRang.Value = 0;
            }
        }
        private void chkNhoRang_CheckedChanged(object sender, EventArgs e)
        {
            nudNhoRang.Enabled = chkNhoRang.Checked;
            if (!chkNhoRang.Checked)
            {
                nudNhoRang.Value = 0;
            }
        }
        private void chkBocRang_CheckedChanged(object sender, EventArgs e)
        {
            nudBocRang.Enabled = chkBocRang.Checked;
            if (!chkBocRang.Checked)
            {
                nudBocRang.Value = 0;
            }
        }
        private void btnTinhTien_Click(object sender, EventArgs e)
        {
            try
            {
                if (string.IsNullOrWhiteSpace(txtCustomerName.Text))
                {
                    MessageBox.Show("Vui lòng nhập tên khách hàng!", "Cảnh báo", 
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtCustomerName.Focus();
                    return;
                }
                if (!chkLayCaoRang.Checked && !chkTayTrangRang.Checked && 
                    !chkHanRang.Checked && !chkNhoRang.Checked && !chkBocRang.Checked)
                {
                    MessageBox.Show("Vui lòng chọn ít nhất một dịch vụ!", "Cảnh báo",
                                  MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
                decimal tongTien = 0;
                if (chkLayCaoRang.Checked)
                {
                    tongTien += GIA_LAY_CAO_RANG;
                }
                if (chkTayTrangRang.Checked)
                {
                    tongTien += GIA_TAY_TRANG_RANG;
                }
                if (chkHanRang.Checked)
                {
                    if (nudHanRang.Value == 0)
                    {
                        MessageBox.Show("Vui lòng nhập số răng cần hàn!", "Cảnh báo",
                                      MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        nudHanRang.Focus();
                        return;
                    }
                    tongTien += GIA_HAN_RANG * nudHanRang.Value;
                }
                if (chkNhoRang.Checked)
                {
                    if (nudNhoRang.Value == 0)
                    {
                        MessageBox.Show("Vui lòng nhập số răng cần nhổ!", "Cảnh báo",
                                      MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        nudNhoRang.Focus();
                        return;
                    }
                    tongTien += GIA_NHO_RANG * nudNhoRang.Value;
                }
                if (chkBocRang.Checked)
                {
                    if (nudBocRang.Value == 0)
                    {
                        MessageBox.Show("Vui lòng nhập số răng cần bọc!", "Cảnh báo",
                                      MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        nudBocRang.Focus();
                        return;
                    }
                    tongTien += GIA_BOC_RANG * nudBocRang.Value;
                }
                txtTongTien.Text = $"Tổng tiền: {tongTien:N0} đ";
                string thongBao = $"Khách hàng: {txtCustomerName.Text.Trim()}\n";
                thongBao += "Dịch vụ đã chọn:\n";
                if (chkLayCaoRang.Checked)
                    thongBao += $"- Lấy cao răng: {GIA_LAY_CAO_RANG:N0} đ\n";
                if (chkTayTrangRang.Checked)
                    thongBao += $"- Tẩy trắng răng: {GIA_TAY_TRANG_RANG:N0} đ\n";
                if (chkHanRang.Checked)
                    thongBao += $"- Hàn răng ({nudHanRang.Value} răng): {GIA_HAN_RANG * nudHanRang.Value:N0} đ\n";
                if (chkNhoRang.Checked)
                    thongBao += $"- Nhổ răng ({nudNhoRang.Value} răng): {GIA_NHO_RANG * nudNhoRang.Value:N0} đ\n";
                if (chkBocRang.Checked)
                    thongBao += $"- Bọc răng ({nudBocRang.Value} răng): {GIA_BOC_RANG * nudBocRang.Value:N0} đ\n";
                thongBao += $"\nTổng cần thanh toán: {tongTien:N0} đ";
                MessageBox.Show(thongBao, "Thông tin thanh toán", 
                              MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi",
                              MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có muốn thoát khỏi chương trình?", 
                                                "Xác nhận thoát", 
                                                MessageBoxButtons.YesNo, 
                                                MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                this.Close();
            }
        }
    }
}
