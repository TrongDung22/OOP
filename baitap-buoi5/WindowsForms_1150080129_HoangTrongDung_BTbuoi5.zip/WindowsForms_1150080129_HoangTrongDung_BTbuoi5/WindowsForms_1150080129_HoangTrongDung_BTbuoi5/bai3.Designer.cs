﻿namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    partial class bai3
    {
        private System.ComponentModel.IContainer components = null;
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }
        private void InitializeComponent()
        {
            this.lblTitle = new System.Windows.Forms.Label();
            this.gbInput = new System.Windows.Forms.GroupBox();
            this.btnAddNumber = new System.Windows.Forms.Button();
            this.txtNumberInput = new System.Windows.Forms.TextBox();
            this.lstNumbers = new System.Windows.Forms.ListBox();
            this.btnIncreaseBy2 = new System.Windows.Forms.Button();
            this.btnSelectFirstEven = new System.Windows.Forms.Button();
            this.btnSelectLastOdd = new System.Windows.Forms.Button();
            this.btnDeleteSelected = new System.Windows.Forms.Button();
            this.btnDeleteFirst = new System.Windows.Forms.Button();
            this.btnDeleteLast = new System.Windows.Forms.Button();
            this.gbFunctions = new System.Windows.Forms.GroupBox();
            this.btnExit = new System.Windows.Forms.Button();
            this.btnClearAll = new System.Windows.Forms.Button();
            this.gbInput.SuspendLayout();
            this.gbFunctions.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTitle
            // 
            this.lblTitle.BackColor = System.Drawing.Color.LightSeaGreen;
            this.lblTitle.Dock = System.Windows.Forms.DockStyle.Top;
            this.lblTitle.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTitle.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.lblTitle.Location = new System.Drawing.Point(0, 0);
            this.lblTitle.Name = "lblTitle";
            this.lblTitle.Size = new System.Drawing.Size(687, 124);
            this.lblTitle.TabIndex = 0;
            this.lblTitle.Text = "Ứng dụng xử lý dãy số";
            this.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbInput
            // 
            this.gbInput.Controls.Add(this.btnAddNumber);
            this.gbInput.Controls.Add(this.txtNumberInput);
            this.gbInput.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbInput.Location = new System.Drawing.Point(12, 142);
            this.gbInput.Name = "gbInput";
            this.gbInput.Size = new System.Drawing.Size(663, 161);
            this.gbInput.TabIndex = 1;
            this.gbInput.TabStop = false;
            this.gbInput.Text = "Nhập số nguyên:";
            // 
            // txtNumberInput
            // 
            this.txtNumberInput.Location = new System.Drawing.Point(80, 64);
            this.txtNumberInput.Multiline = true;
            this.txtNumberInput.Name = "txtNumberInput";
            this.txtNumberInput.Size = new System.Drawing.Size(366, 47);
            this.txtNumberInput.TabIndex = 0;
            this.txtNumberInput.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumberInput_KeyPress);
            this.txtNumberInput.KeyDown += new System.Windows.Forms.KeyEventHandler(this.txtNumberInput_KeyDown);
            // 
            // btnAddNumber
            // 
            this.btnAddNumber.Location = new System.Drawing.Point(507, 64);
            this.btnAddNumber.Name = "btnAddNumber";
            this.btnAddNumber.Size = new System.Drawing.Size(102, 47);
            this.btnAddNumber.TabIndex = 1;
            this.btnAddNumber.Text = "Nhập số";
            this.btnAddNumber.UseVisualStyleBackColor = true;
            this.btnAddNumber.Click += new System.EventHandler(this.btnAddNumber_Click);
            // 
            // lstNumbers
            // 
            this.lstNumbers.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstNumbers.FormattingEnabled = true;
            this.lstNumbers.ItemHeight = 29;
            this.lstNumbers.Location = new System.Drawing.Point(12, 323);
            this.lstNumbers.Name = "lstNumbers";
            this.lstNumbers.Size = new System.Drawing.Size(282, 468);
            this.lstNumbers.TabIndex = 2;
            // 
            // btnIncreaseBy2
            // 
            this.btnIncreaseBy2.Location = new System.Drawing.Point(31, 43);
            this.btnIncreaseBy2.Name = "btnIncreaseBy2";
            this.btnIncreaseBy2.Size = new System.Drawing.Size(265, 47);
            this.btnIncreaseBy2.TabIndex = 3;
            this.btnIncreaseBy2.Text = "Tăng mỗi phần tử lên 2";
            this.btnIncreaseBy2.UseVisualStyleBackColor = true;
            this.btnIncreaseBy2.Click += new System.EventHandler(this.btnIncreaseBy2_Click);
            // 
            // btnSelectFirstEven
            // 
            this.btnSelectFirstEven.Location = new System.Drawing.Point(31, 114);
            this.btnSelectFirstEven.Name = "btnSelectFirstEven";
            this.btnSelectFirstEven.Size = new System.Drawing.Size(265, 47);
            this.btnSelectFirstEven.TabIndex = 4;
            this.btnSelectFirstEven.Text = "Chọn số chẵn đầu";
            this.btnSelectFirstEven.UseVisualStyleBackColor = true;
            this.btnSelectFirstEven.Click += new System.EventHandler(this.btnSelectFirstEven_Click);
            // 
            // btnSelectLastOdd
            // 
            this.btnSelectLastOdd.Location = new System.Drawing.Point(31, 185);
            this.btnSelectLastOdd.Name = "btnSelectLastOdd";
            this.btnSelectLastOdd.Size = new System.Drawing.Size(265, 47);
            this.btnSelectLastOdd.TabIndex = 5;
            this.btnSelectLastOdd.Text = "Chọn số lẻ cuối";
            this.btnSelectLastOdd.UseVisualStyleBackColor = true;
            this.btnSelectLastOdd.Click += new System.EventHandler(this.btnSelectLastOdd_Click);
            // 
            // btnDeleteSelected
            // 
            this.btnDeleteSelected.Location = new System.Drawing.Point(31, 256);
            this.btnDeleteSelected.Name = "btnDeleteSelected";
            this.btnDeleteSelected.Size = new System.Drawing.Size(265, 47);
            this.btnDeleteSelected.TabIndex = 6;
            this.btnDeleteSelected.Text = "Xóa phần tử đang chọn";
            this.btnDeleteSelected.UseVisualStyleBackColor = true;
            this.btnDeleteSelected.Click += new System.EventHandler(this.btnDeleteSelected_Click);
            // 
            // btnDeleteFirst
            // 
            this.btnDeleteFirst.Location = new System.Drawing.Point(31, 327);
            this.btnDeleteFirst.Name = "btnDeleteFirst";
            this.btnDeleteFirst.Size = new System.Drawing.Size(265, 47);
            this.btnDeleteFirst.TabIndex = 7;
            this.btnDeleteFirst.Text = "Xóa phần tử đầu";
            this.btnDeleteFirst.UseVisualStyleBackColor = true;
            this.btnDeleteFirst.Click += new System.EventHandler(this.btnDeleteFirst_Click);
            // 
            // btnDeleteLast
            // 
            this.btnDeleteLast.Location = new System.Drawing.Point(31, 398);
            this.btnDeleteLast.Name = "btnDeleteLast";
            this.btnDeleteLast.Size = new System.Drawing.Size(265, 47);
            this.btnDeleteLast.TabIndex = 8;
            this.btnDeleteLast.Text = "Xóa phần tử cuối";
            this.btnDeleteLast.UseVisualStyleBackColor = true;
            this.btnDeleteLast.Click += new System.EventHandler(this.btnDeleteLast_Click);
            // 
            // gbFunctions
            // 
            this.gbFunctions.Controls.Add(this.btnIncreaseBy2);
            this.gbFunctions.Controls.Add(this.btnSelectFirstEven);
            this.gbFunctions.Controls.Add(this.btnDeleteLast);
            this.gbFunctions.Controls.Add(this.btnSelectLastOdd);
            this.gbFunctions.Controls.Add(this.btnDeleteFirst);
            this.gbFunctions.Controls.Add(this.btnDeleteSelected);
            this.gbFunctions.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.gbFunctions.Location = new System.Drawing.Point(325, 323);
            this.gbFunctions.Name = "gbFunctions";
            this.gbFunctions.Size = new System.Drawing.Size(337, 484);
            this.gbFunctions.TabIndex = 9;
            this.gbFunctions.TabStop = false;
            this.gbFunctions.Text = "Chức năng:";
            // 
            // btnExit
            // 
            this.btnExit.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnExit.Location = new System.Drawing.Point(56, 857);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(215, 47);
            this.btnExit.TabIndex = 10;
            this.btnExit.Text = "Kết thúc ứng dụng";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // btnClearAll
            // 
            this.btnClearAll.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnClearAll.Location = new System.Drawing.Point(454, 857);
            this.btnClearAll.Name = "btnClearAll";
            this.btnClearAll.Size = new System.Drawing.Size(167, 47);
            this.btnClearAll.TabIndex = 11;
            this.btnClearAll.Text = "Xóa dãy số";
            this.btnClearAll.UseVisualStyleBackColor = true;
            this.btnClearAll.Click += new System.EventHandler(this.btnClearAll_Click);
            // 
            // bai3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(687, 936);
            this.Controls.Add(this.btnClearAll);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.lstNumbers);
            this.Controls.Add(this.gbInput);
            this.Controls.Add(this.lblTitle);
            this.Controls.Add(this.gbFunctions);
            this.Name = "bai3";
            this.Text = "Ứng dụng xử lý dãy số";
            this.gbInput.ResumeLayout(false);
            this.gbInput.PerformLayout();
            this.gbFunctions.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.GroupBox gbInput;
        private System.Windows.Forms.Button btnAddNumber;
        private System.Windows.Forms.TextBox txtNumberInput;
        private System.Windows.Forms.ListBox lstNumbers;
        private System.Windows.Forms.Button btnIncreaseBy2;
        private System.Windows.Forms.Button btnSelectFirstEven;
        private System.Windows.Forms.Button btnSelectLastOdd;
        private System.Windows.Forms.Button btnDeleteSelected;
        private System.Windows.Forms.Button btnDeleteFirst;
        private System.Windows.Forms.Button btnDeleteLast;
        private System.Windows.Forms.GroupBox gbFunctions;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Button btnClearAll;
    }
}