﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsForms_1150080129_HoangTrongDung_BTbuoi5
{
    public partial class bai3 : Form
    {
        public bai3()
        {
            InitializeComponent();
            this.Load += (s, e) => txtNumberInput.Focus();
        }

        private void txtNumberInput_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
            {
                if (e.KeyChar == '-')
                {
                    TextBox txt = sender as TextBox;
                    if (txt.SelectionStart != 0 || txt.Text.Contains("-"))
                    {
                        e.Handled = true;
                    }
                }
                else
                {
                    e.Handled = true;
                }
            }
        }

        private void txtNumberInput_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                AddNumberToList();
                e.Handled = true;
            }
        }

        private void btnAddNumber_Click(object sender, EventArgs e)
        {
            AddNumberToList();
        }

        private void AddNumberToList()
        {
            if (!string.IsNullOrWhiteSpace(txtNumberInput.Text))
            {
                if (int.TryParse(txtNumberInput.Text, out int number))
                {
                    lstNumbers.Items.Add(number);
                    txtNumberInput.Clear();
                    txtNumberInput.Focus();
                }
                else
                {
                    MessageBox.Show("Vui lòng nhập một số nguyên hợp lệ!", "Lỗi", 
                        MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    txtNumberInput.SelectAll();
                    txtNumberInput.Focus();
                }
            }
        }

        private void btnIncreaseBy2_Click(object sender, EventArgs e)
        {
            if (lstNumbers.Items.Count == 0)
            {
                MessageBox.Show("Danh sách rỗng!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            for (int i = 0; i < lstNumbers.Items.Count; i++)
            {
                int currentValue = (int)lstNumbers.Items[i];
                lstNumbers.Items[i] = currentValue + 2;
            }
        }

        private void btnSelectFirstEven_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstNumbers.Items.Count; i++)
            {
                int number = (int)lstNumbers.Items[i];
                if (number % 2 == 0)
                {
                    lstNumbers.SelectedIndex = i;
                    return;
                }
            }
            MessageBox.Show("Không tìm thấy số chẵn nào trong danh sách!", "Thông báo", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSelectLastOdd_Click(object sender, EventArgs e)
        {
            for (int i = lstNumbers.Items.Count - 1; i >= 0; i--)
            {
                int number = (int)lstNumbers.Items[i];
                if (number % 2 != 0)
                {
                    lstNumbers.SelectedIndex = i;
                    return;
                }
            }
            MessageBox.Show("Không tìm thấy số lẻ nào trong danh sách!", "Thông báo", 
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDeleteSelected_Click(object sender, EventArgs e)
        {
            if (lstNumbers.SelectedIndex >= 0)
            {
                lstNumbers.Items.RemoveAt(lstNumbers.SelectedIndex);
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một phần tử để xóa!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnDeleteFirst_Click(object sender, EventArgs e)
        {
            if (lstNumbers.Items.Count > 0)
            {
                lstNumbers.Items.RemoveAt(0);
            }
            else
            {
                MessageBox.Show("Danh sách rỗng!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnDeleteLast_Click(object sender, EventArgs e)
        {
            if (lstNumbers.Items.Count > 0)
            {
                lstNumbers.Items.RemoveAt(lstNumbers.Items.Count - 1);
            }
            else
            {
                MessageBox.Show("Danh sách rỗng!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnClearAll_Click(object sender, EventArgs e)
        {
            if (lstNumbers.Items.Count > 0)
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa tất cả các số?", 
                    "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (result == DialogResult.Yes)
                {
                    lstNumbers.Items.Clear();
                }
            }
            else
            {
                MessageBox.Show("Danh sách đã rỗng!", "Thông báo", 
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thoát ứng dụng?", 
                "Xác nhận thoát", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
    }
}
